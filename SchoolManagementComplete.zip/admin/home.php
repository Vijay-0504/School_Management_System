<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Management System</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: #141E30;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #243B55, #141E30);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #243B55, #141E30); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

        }

        /* Navbar Styling */
        .navbar {
            position: sticky;
            top: 0;
            background-color: #333;
            padding: 10px 0;
            text-align: center;
            z-index: 100;
        }
        .navbar a {
            display: inline-block;
            padding: 14px 20px;
            color: white;
            text-decoration: none;
            text-align: center;
            font-size: 16px;
        }
        .navbar a:hover {
            background-color: #575757;
        }
        .navbar a.logout {
            float: right;
            background-color: red;
        }

        /* Hero Section */
        .hero {
            background: url('https://via.placeholder.com/1500x600') no-repeat center center/cover;
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        .hero h1 {
            font-size: 50px;
            margin-bottom: 10px;
        }
        .hero p {
            font-size: 18px;
            margin-bottom: 20px;
        }
        .cta-button {
            background-color: #4CAF50;
            color: white;
            padding: 15px 30px;
            font-size: 18px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .cta-button:hover {
            background-color: #45a049;
        }

        /* Cards Section */
        .cards-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            padding: 40px 20px;
        }
        .card {
            background: #EFEFBB;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #D4D3DD, #EFEFBB);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #D4D3DD, #EFEFBB); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-10px);
        }
        .card h3 {
            font-size: 24px;
            margin-bottom: 15px;
        }
        .card p {
            font-size: 16px;
            color: #555;
        }

        /* Statistics Section */
        .stats {
            background: #141E30;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #243B55, #141E30);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #243B55, #141E30); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

            padding: 60px 20px;
            text-align: center;
        }
        .stats .stat-card {
            display: inline-block;
            width: 30%;
            margin: 10px 10px;
            background: #EFEFBB;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #D4D3DD, #EFEFBB);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #D4D3DD, #EFEFBB); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */


            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .stats .stat-card:hover {
            transform: translateY(-50px);
        }
        .stat-card h4 {
            font-size: 28px;
            margin-bottom: 15px;
        }
        .stat-card span {
            font-size: 36px;
            font-weight: bold;
            color: #4CAF50;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
        }
        footer a {
            color: white;
            text-decoration: none;
            padding: 10px;
        }
        footer a:hover {
            background-color: #575757;
        }

        /* Mobile Styles */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 40px;
            }
            .hero p {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <a href="add_student.php">Add Student</a>
        <a href="enter_marks.php">Add Marks</a>
        <a href="print_reports.php">Print Reports</a>
        <a href="mark_attendance.php">Mark Attendance</a>
        <a href="generate_grade.php">Generate Grade Sheets</a>
        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <!-- Hero Section -->
    <div class="hero">
        <h1>Welcome to School Management System</h1>
        <p>Your one-stop solution for managing students, attendance, grades, and more!</p>
        <button class="cta-button" onclick="window.location.href='mark_attendance.php'">Start Managing Attendance</button>
    </div>

    <!-- Cards Section -->
    <div class="cards-container">
        <div class="card">
            <h3>Mark Attendance</h3>
            <p>Record student attendance with ease and track their performance over time.</p>
        </div>
        <div class="card">
            <h3>Generate Reports</h3>
            <p>Create customized reports for students, including marks, attendance, and grades.</p>
        </div>
        <div class="card">
            <h3>Add Students</h3>
            <p>Easily add new students to the system and track their progress throughout the academic year.</p>
        </div>
        <div class="card">
            <h3>Easy Analysis</h3>
            <p>Easily Analyse the system and track their progress throughout the academic year.</p>
        </div>
    </div>

    <!-- Statistics Section -->
    <div class="stats">
        <div class="stat-card">
            <h4>Total Students</h4>
            <span>500</span>
        </div>
        <div class="stat-card">
            <h4>Average Attendance</h4>
            <span>85%</span>
        </div>
        <div class="stat-card">
            <h4>Reports Generated</h4>
            <span>120</span>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 School Management System | <a href="#">Privacy Policy</a> | <a href="#">Contact Us</a></p>
    </footer>

</body>
</html>
